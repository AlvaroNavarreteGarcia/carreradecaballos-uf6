public class Main {
    public static void main(String[] args) {
        CarreraCaballos juego = new CarreraCaballos();
        juego.iniciarJuego();
    }
}

