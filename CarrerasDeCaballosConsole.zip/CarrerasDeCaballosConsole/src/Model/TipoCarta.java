package Model;

public enum TipoCarta {
    BASTOS,
    OROS,
    ESPADAS,
    COPAS
}
