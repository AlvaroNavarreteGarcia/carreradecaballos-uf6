La implementación de este proyecto es funcional pero no es òptima desde el punto de vista de la orientación a objetos.
-La classe CarreraCaballos contiene lògica de aplicación y interección con usuario por consola, deberian separararse con dos classes distinttas:
	Por ejemplo la dinàmica de movimiento de los caballos(logica de aplicación) en una classe del modelo llamada CarreraCaballos.
	Input/output de consola en una classe llamada CarreraCaballosController